﻿http://www.adobe.com/devnet/createjs/articles/getting-started.html

Most browsers (with the exception of Safari), will throw a security error if you run this content locally and click on the background. This is because EaselJS reads pixel data to determine what you clicked on, and most browsers don’t allow pixel access on local images.

Run the content from a server, or temporarily disable local security in your browser to test.
